# Python Basics Practice assignment 3
# By Gabriel Smith

print("I've heard that " + input("What country are you from?") +
      " is a beautiful country!")
