# Python Basics Practice assignment 4
# By Gabriel Smith

for i in range(11):
    print("4 multiplied by " + str(i) + " is " + str(4*i))
